#include "Book.hpp"
#include <cstring>

// EFFECTS: make a copy of the C-style string in
//  on the heap.
char *duplicate_c_string(const char *in) {
    int length = strlen(in);
    char *copy = new char[length + 1];
    strncpy(copy, in, length + 1);
    return copy;
}

// Your code here