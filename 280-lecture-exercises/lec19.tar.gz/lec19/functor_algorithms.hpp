#pragma once
#include <cassert>

// Note: all coding will be done in .hpp files for this lecture.
// You do not need to create any .cpp files.

class MultipleOfTenMatcher {
public:
    // EFFECTS: returns true if and only if val is
    //  a multiple of 10.
    bool operator()(int val) {
        // your code here
        assert(false);
    }
};

class GreaterThanMatcher {
public:
    GreaterThanMatcher(int target) : target(target) {
        // your code here. You may add an initializer list too.
    }
    // EFFECTS: returns true if and only if val is
    //  greater than target.
    bool operator()(int val) {
        // your code here
        assert(false);
    }
private:
    int target;
};

// EFFECTS: returns the number of elements between
//  begin and end for which the matcher returns true
template<typename Iter_type, typename Functor_type>
int count_matches(Iter_type begin, Iter_type end, Functor_type &matcher) {
    // your code here
    assert(false);
}

// EFFECTS: returns the number of items between begin and end
//  that are a multiple of 10.
template<typename Iter_type>
int count_multiples_10(Iter_type begin, Iter_type end) {
    MultipleOfTenMatcher matcher;
    // your code here. You must use count_matches in your solution.
    assert(false);
}

// EFFECTS: returns the number of items between begin and end
//  that are greater than val.
template<typename Iter_type>
int count_greater_than(Iter_type begin, Iter_type end, int val) {
    // your code here.
    assert(false);
}
